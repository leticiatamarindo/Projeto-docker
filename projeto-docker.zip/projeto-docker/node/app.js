const http = require('http');

const hostname = '0.0.0.0';  // Ou coloque o host desejado
const port = 3000;  // A porta em que sua aplicação será executada

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, Meu nome e Leticia e estou testando as funcionalidades do docker!!\n');
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
